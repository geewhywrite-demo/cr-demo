# Flask Demo App

A minimal Flask web app to learn how GitHub works.

## How to run

```bash
pip install -r requirements.txt
python app.py

Visit http://localhost:5000 in your browser.

```

